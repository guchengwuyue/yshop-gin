<template>
  <div class="cartContainer">
      <router-view> </router-view>
  </div>
</template>

<script>
export default {

}
</script>
