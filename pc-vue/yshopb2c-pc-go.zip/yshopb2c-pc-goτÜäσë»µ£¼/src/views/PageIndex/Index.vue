<template>
  <div class="pageIndex">
      <router-view></router-view>
  </div>
</template>

<style lang="scss">
.pageIndex{
  min-width: 1440px;
  background-color: #F6F6F8;
}
</style>
