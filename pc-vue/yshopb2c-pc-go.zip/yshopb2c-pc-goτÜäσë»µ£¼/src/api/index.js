export const requestConfig = {
  url: 'http://localhost:8000/api/v1',
  // url: '/proxy',
  timeout: 30000
}
