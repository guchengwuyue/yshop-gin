<template>
  <div class="notfoundTicket">
      <el-image src="static\images\NofFound\yhq.webp" ></el-image>
        <span>暂无可用优惠卷~</span>
  </div>
</template>

<style lang="scss">
.notfoundTicket{
    span{
        display: block;
        text-align: center;
        margin-top: 20px;
        color: #333333;
        font-size: 20px;
        font-weight: 700;
    }
}
</style>
