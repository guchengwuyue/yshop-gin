export const SET_USERINFO = 'SET_USERINFO'
export const SET_CARTNUM = 'SET_CARTNUM'
