/**
 * 根据class获得元素
 * @param {className} class名称
 * @param {tagName} 标签名称
 */
export function test () {
  console.log('test')
}
