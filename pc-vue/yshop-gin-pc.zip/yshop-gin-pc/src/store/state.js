const state = {
  loginVisible: false, // 登录注册弹窗
  userInfo: {}, // 用户信息
  cartNum: 0 // 购物车商品数量
}

export default state
