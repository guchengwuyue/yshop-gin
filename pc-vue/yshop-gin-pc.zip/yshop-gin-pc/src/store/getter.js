export const loginVisible = state => state.loginVisible
export const userInfo = state => state.userInfo
export const cartNum = state => state.cartNum
