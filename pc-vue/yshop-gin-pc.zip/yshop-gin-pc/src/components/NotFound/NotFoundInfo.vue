<template>
    <div class="notFoundInfo">
        <el-image src="static\images\NofFound\wsj.webp" ></el-image>
        <span>暂无数据哦~</span>
    </div>
</template>
<style lang="scss">
.notFoundInfo{
    padding: 20px;
    img{
        display: block;
        margin: auto;
    }
    span{
        display: block;
        text-align: center;
        margin-top: 20px;
        color: #333333;
        font-size: 20px;
        font-weight: 700;
    }
}
</style>
