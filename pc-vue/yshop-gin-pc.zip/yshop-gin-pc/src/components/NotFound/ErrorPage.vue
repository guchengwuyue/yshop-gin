<template>
  <div class="errpage">
      <el-image src="static\images\NofFound\mw.webp"></el-image>
        <span>页面飞到外太空了呀~~~</span>
  </div>
</template>

<style lang="scss">
.errpage{
    span{
        display: block;
        text-align: center;
        margin-top: 20px;
        color: #333333;
        font-size: 20px;
        font-weight: 700;
    }
}
</style>
